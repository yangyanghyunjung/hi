


var player=prompt("가위,바위,보 입력하세요.");


var com=Math.floor(Math.random()*3)+1;

document.write("com : " + com+"<br>");
document.write("player : " + player+"<br>");




// 컴퓨터가 가위 냈을때
if(com==1){
    if(player=="바위"){
        document.write("이겼습니다.");
    }
    else if( player=="가위"){
        document.write("비겼습니다.");
    }
   
   else if(  player=="보"){
        document.write("졌습니다.");
    }
   

}
    




// 컴퓨터가 바위 냈을때
if(com==2){
    if(player=="보"){
        document.write("이겼습니다.");
    }
    else if(player=="바위"){
        document.write("비겼습니다.");
    }
    else if(player== "가위"){
        document.write("졌습니다.");
    }
   

}




// 컴퓨터가 보 냈을때
if(com==3){
    if(player=="가위"){
        document.write("이겼습니다.");
    }
    else if(player=="보"){
        document.write("비겼습니다.");
    }
    else if(player=="바위"){
        document.write("졌습니다.");
    }

}




var player=prompt("가위,바위,보 입력하세요.");


var com=Math.floor(Math.random()*3)+1;

document.write("com : " + com+"<br>");
document.write("player : " + player+"<br>");




// 컴퓨터가 가위 냈을때
if(com==1){
    if(player=="바위"){
        document.write("이겼습니다.");
    }
    else if( player=="가위"){
        document.write("비겼습니다.");
    }
   
   else if(  player=="보"){
        document.write("졌습니다.");
    }
   

}
    




// 컴퓨터가 바위 냈을때
if(com==2){
    if(player=="보"){
        document.write("이겼습니다.");
    }
    else if(player=="바위"){
        document.write("비겼습니다.");
    }
    else if(player== "가위"){
        document.write("졌습니다.");
    }
   

}




// 컴퓨터가 보 냈을때
if(com==3){
    if(player=="가위"){
        document.write("이겼습니다.");
    }
    else if(player=="보"){
        document.write("비겼습니다.");
    }
    else if(player=="바위"){
        document.write("졌습니다.");
    }

}






 




 