package com.peisia.mapper;

import com.peisia.domain.TestVO;

public interface TestMapper {
	public TestVO getData1();
	public TestVO getData2();
	public TestVO getData3();
	public TestVO getData4();
	
	public void updateVisitantCount(); //문제1
	public void insertDoodle();  //문제2
	public void delTest(); //문제3
	
}
