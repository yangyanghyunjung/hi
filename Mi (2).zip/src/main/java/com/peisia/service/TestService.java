package com.peisia.service;

public interface TestService {
	public String getOne();
	public String getTwo();
	
	
	public void updateVisitantCount(); // 문제1
	public void insertDoodle(); // 문제2
	public void delTest(); //문제3
	
}
