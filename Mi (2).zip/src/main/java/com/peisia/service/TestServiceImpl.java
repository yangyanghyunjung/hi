package com.peisia.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.domain.TestVO;
import com.peisia.mapper.TestMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
//@AllArgsConstructor
public class TestServiceImpl implements TestService{

	@Setter(onMethod_ = @Autowired)
	private TestMapper mapper;	
	
	@Override
	public String getOne() {
		log.info("test===========");
		TestVO tvo = mapper.getData1();
		String one = tvo.getStr_data();
		log.info("======서비스쪽 값1구하기:"+one);
		return one;
	}

	@Override
	public String getTwo() {
		log.info("test===========");
		TestVO tvo = mapper.getData2();
		String two = tvo.getStr_data();
		log.info("======서비스쪽 값2구하기:"+two);
		return two;
	}
	//문제1
	@Override
	public void updateVisitantCount() {
		mapper.updateVisitantCount();
	}
	
	 //문제2
	 @Override 
	 public void insertDoodle() {
		mapper.insertDoodle();
	 }
	  
	 //문제3
	 @Override 
	 public void delTest() {
		 mapper.delTest();
	 }
	 

}
