package com.peisia.domain;

import lombok.Data;

@Data
public class TestVO {
	private Long no;
	private String str_data;
}