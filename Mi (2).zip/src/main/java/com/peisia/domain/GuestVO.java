package com.peisia.domain;

import lombok.Data;

@Data
public class GuestVO {
	//VO : 값을 저장하는 애
	private Long bno;
	private String btext;
}

/*
 * //이런 애들을 게터 
 * public Long getBno() {
 *  return bno; 
 *  } 
 * //이런 애들을 세터 
 * public void setBno(Long bno)
 *  { 
 *  this.bno=bno; 
 *  }
 */