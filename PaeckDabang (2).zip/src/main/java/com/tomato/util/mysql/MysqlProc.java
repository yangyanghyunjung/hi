package com.tomato.util.mysql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MysqlProc {

	static private Connection con = null;
	static private Statement st = null;
	
	static public void initDb() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
	}	
	
	static public void connectDb() {
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/my_board", "root", "admin");
			st = con.createStatement();
			System.out.println("==== 디비 접속 성공");
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	static public ResultSet exeQuery(String sql) {
		try {
			return st.executeQuery(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	static public int exeUpdate(String sql) {
		try {
			return st.executeUpdate(sql);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -100;
	}
	
	static public void disconnectDb() {
		try {
			if(st!=null) {
				st.close();
			}
			if(con!=null) {
				con.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
