package com.tomato.util.mysql;

public class Basket {
	public String name;
	
	public int price;

	public Basket(String name, int price) {
		this.name = name;
		this.price = price;
	}

	
}
